﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
namespace CybersecurityAwarenessChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            // Play voice greeting
            SoundPlayer player = new SoundPlayer("c:\Users\Rc_Student_lab\Desktop");
            player.Play();

          
            // Ask for user's name
            Console.Write("What is your name? ");
            string userName = Console.ReadLine();

            // Display personalized welcome message
            Console.WriteLine($"Hello, {userName}! Welcome to the Cybersecurity Awareness Bot.");

            // Main chatbot loop
            while (true)
            {
                Console.Write("What's your question? ");
                string userQuestion = Console.ReadLine();

                // Respond to basic cybersecurity-related questions
                Dictionary<string, string> responses = new Dictionary<string, string>
                {
                    {"How are you?", "I'm doing well, thanks for asking!"},
                    {"What can I ask about?", "You can ask me about password safety, phishing, and safe browsing."}
                };

                if (responses.ContainsKey(userQuestion))
                {
                    Console.WriteLine(responses[userQuestion]);
                }
                else
                {
                    Console.WriteLine("I didn't quite understand that. Could you rephrase?");
                }
            }
        }
    }
}



